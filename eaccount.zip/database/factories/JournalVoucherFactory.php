<?php

use Faker\Generator as Faker;

$factory->define(App\JournalVoucher::class, function (Faker $faker) {
    return [
        //
    ];
});
