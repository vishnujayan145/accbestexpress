<?php

use Faker\Generator as Faker;

$factory->define(App\InitialBankCashBalance::class, function (Faker $faker) {
    return [
        //
    ];
});
