<?php

use Faker\Generator as Faker;

$factory->define(App\InitialIncomeExpenseHeadBalance::class, function (Faker $faker) {
    return [
        //
    ];
});
