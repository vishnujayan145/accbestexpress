<?php

use Faker\Generator as Faker;

$factory->define(App\DrVoucher::class, function (Faker $faker) {
    return [
        //
    ];
});
