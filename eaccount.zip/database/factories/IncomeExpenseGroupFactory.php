<?php

use Faker\Generator as Faker;

$factory->define(App\IncomeExpenseGroup::class, function (Faker $faker) {
    return [
        //
    ];
});
