<?php

use Faker\Generator as Faker;

$factory->define(App\IncomeExpenseHead::class, function (Faker $faker) {
    return [
        //
    ];
});
