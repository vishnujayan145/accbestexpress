<?php

return [
    'cost_of_revenue' => [102, 104, 114, 115],
    'profit_or_loss' => [102, 104, 114, 115, 105, 106, 116, 117],
    'retained_earnings' => [102, 104, 114, 115, 105, 106, 116, 117, 122],
    'fix_asset_schedule' => [119],
    'balance_sheet' => [108, 113, 109, 107, 110, 112, 111, 120, 103, 101, 121]
];
